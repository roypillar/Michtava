..........................
      o          o
.ooo..o..o..ooo..o...oooo.
o   o o.o  o ..  o   .oo.
.ooo..o..o..ooo...oo.ooooo

BEST  QUALITY  SINCE  1998
http://www.oketz.com/fonts
FREE HEBREW FONT DOWNLOAD!
THE BEST  o-9  DAY  FONTz!
=-=-=-:This release:-=-=-=
          KAMMER
      for Windows 95+
    Regular + X Version
=-=-=-=-=-=--=-=-=-=-=-=-=
This  font started  as one
of  many  experiments  for
finding    simple   Hebrew
forms. The method I worked
with in this font is simil-
ar  to  building  a wooden
rhapsody - cutting,  break-
ing,  tying, connecting. I
used a differently  shaped
"mem"  here,  like in  the
"Goldstar"  font.   Kammer
was a kid in  my classroom.
=-=-=-=-=-=--=-=-=-=-=-=-=
Copyright � MeiR SaDaN (!)
